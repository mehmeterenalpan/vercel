import { withContentlayer } from "next-contentlayer";
const nextConfig = {
  output: 'export',
  images: { unoptimized: true },
  experimental: { typedRoutes: true },
};
export default withContentlayer(nextConfig);
